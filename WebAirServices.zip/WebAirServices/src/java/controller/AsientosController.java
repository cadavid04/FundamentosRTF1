package controller;

import Entity.Asientos;
import Entity.DetalleCompras;
import java.util.Collection;
import facade.AsientosFacade;
import controller.util.MobilePageController;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

@Named(value = "asientosController")
@ViewScoped
public class AsientosController extends AbstractController<Asientos> {

    @Inject
    private MobilePageController mobilePageController;

    // Flags to indicate if child collections are empty
    private boolean isDetalleComprasCollectionEmpty;

    public AsientosController() {
        // Inform the Abstract parent controller of the concrete Asientos Entity
        super(Asientos.class);
    }

    /**
     * Set the "is[ChildCollection]Empty" property for OneToMany fields.
     */
    @Override
    protected void setChildrenEmptyFlags() {
        this.setIsDetalleComprasCollectionEmpty();
    }

    public boolean getIsDetalleComprasCollectionEmpty() {
        return this.isDetalleComprasCollectionEmpty;
    }

    private void setIsDetalleComprasCollectionEmpty() {
        Asientos selected = this.getSelected();
        if (selected != null) {
            AsientosFacade ejbFacade = (AsientosFacade) this.getFacade();
            this.isDetalleComprasCollectionEmpty = ejbFacade.isDetalleComprasCollectionEmpty(selected);
        } else {
            this.isDetalleComprasCollectionEmpty = true;
        }
    }

    /**
     * Sets the "items" attribute with a collection of DetalleCompras entities
     * that are retrieved from Asientos and returns the navigation outcome.
     *
     * @return navigation outcome for DetalleCompras page
     */
    public String navigateDetalleComprasCollection() {
        Asientos selected = this.getSelected();
        if (selected != null) {
            AsientosFacade ejbFacade = (AsientosFacade) this.getFacade();
            Collection<DetalleCompras> selectedDetalleComprasCollection = ejbFacade.findDetalleComprasCollection(selected);
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("DetalleCompras_items", selectedDetalleComprasCollection);
        }
        return this.mobilePageController.getMobilePagesPrefix() + "/app/detalleCompras/index";
    }

}

package controller;

import Entity.Socios;
import Entity.Compras;
import java.util.Collection;
import facade.SociosFacade;
import controller.util.MobilePageController;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

@Named(value = "sociosController")
@ViewScoped
public class SociosController extends AbstractController<Socios> {

    @Inject
    private MobilePageController mobilePageController;

    // Flags to indicate if child collections are empty
    private boolean isComprasCollectionEmpty;

    public SociosController() {
        // Inform the Abstract parent controller of the concrete Socios Entity
        super(Socios.class);
    }

    /**
     * Set the "is[ChildCollection]Empty" property for OneToMany fields.
     */
    @Override
    protected void setChildrenEmptyFlags() {
        this.setIsComprasCollectionEmpty();
    }

    public boolean getIsComprasCollectionEmpty() {
        return this.isComprasCollectionEmpty;
    }

    private void setIsComprasCollectionEmpty() {
        Socios selected = this.getSelected();
        if (selected != null) {
            SociosFacade ejbFacade = (SociosFacade) this.getFacade();
            this.isComprasCollectionEmpty = ejbFacade.isComprasCollectionEmpty(selected);
        } else {
            this.isComprasCollectionEmpty = true;
        }
    }

    /**
     * Sets the "items" attribute with a collection of Compras entities that are
     * retrieved from Socios and returns the navigation outcome.
     *
     * @return navigation outcome for Compras page
     */
    public String navigateComprasCollection() {
        Socios selected = this.getSelected();
        if (selected != null) {
            SociosFacade ejbFacade = (SociosFacade) this.getFacade();
            Collection<Compras> selectedComprasCollection = ejbFacade.findComprasCollection(selected);
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("Compras_items", selectedComprasCollection);
        }
        return this.mobilePageController.getMobilePagesPrefix() + "/app/compras/index";
    }

}

package controller;

import Entity.Compras;
import Entity.DetalleCompras;
import java.util.Collection;
import facade.ComprasFacade;
import controller.util.MobilePageController;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;

@Named(value = "comprasController")
@ViewScoped
public class ComprasController extends AbstractController<Compras> {

    @Inject
    private SociosController idSocioController;
    @Inject
    private VuelosController idVueloController;
    @Inject
    private MobilePageController mobilePageController;

    // Flags to indicate if child collections are empty
    private boolean isDetalleComprasCollectionEmpty;

    public ComprasController() {
        // Inform the Abstract parent controller of the concrete Compras Entity
        super(Compras.class);
    }

    /**
     * Resets the "selected" attribute of any parent Entity controllers.
     */
    public void resetParents() {
        idSocioController.setSelected(null);
        idVueloController.setSelected(null);
    }

    /**
     * Set the "is[ChildCollection]Empty" property for OneToMany fields.
     */
    @Override
    protected void setChildrenEmptyFlags() {
        this.setIsDetalleComprasCollectionEmpty();
    }

    /**
     * Sets the "selected" attribute of the Socios controller in order to
     * display its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareIdSocio(ActionEvent event) {
        Compras selected = this.getSelected();
        if (selected != null && idSocioController.getSelected() == null) {
            idSocioController.setSelected(selected.getIdSocio());
        }
    }

    /**
     * Sets the "selected" attribute of the Vuelos controller in order to
     * display its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareIdVuelo(ActionEvent event) {
        Compras selected = this.getSelected();
        if (selected != null && idVueloController.getSelected() == null) {
            idVueloController.setSelected(selected.getIdVuelo());
        }
    }

    public boolean getIsDetalleComprasCollectionEmpty() {
        return this.isDetalleComprasCollectionEmpty;
    }

    private void setIsDetalleComprasCollectionEmpty() {
        Compras selected = this.getSelected();
        if (selected != null) {
            ComprasFacade ejbFacade = (ComprasFacade) this.getFacade();
            this.isDetalleComprasCollectionEmpty = ejbFacade.isDetalleComprasCollectionEmpty(selected);
        } else {
            this.isDetalleComprasCollectionEmpty = true;
        }
    }

    /**
     * Sets the "items" attribute with a collection of DetalleCompras entities
     * that are retrieved from Compras and returns the navigation outcome.
     *
     * @return navigation outcome for DetalleCompras page
     */
    public String navigateDetalleComprasCollection() {
        Compras selected = this.getSelected();
        if (selected != null) {
            ComprasFacade ejbFacade = (ComprasFacade) this.getFacade();
            Collection<DetalleCompras> selectedDetalleComprasCollection = ejbFacade.findDetalleComprasCollection(selected);
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("DetalleCompras_items", selectedDetalleComprasCollection);
        }
        return this.mobilePageController.getMobilePagesPrefix() + "/app/detalleCompras/index";
    }

}

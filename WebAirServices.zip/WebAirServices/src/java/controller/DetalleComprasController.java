package controller;

import Entity.DetalleCompras;
import facade.DetalleComprasFacade;
import controller.util.MobilePageController;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;

@Named(value = "detalleComprasController")
@ViewScoped
public class DetalleComprasController extends AbstractController<DetalleCompras> {

    @Inject
    private AsientosController idAsientoController;
    @Inject
    private ComprasController idCompraController;
    @Inject
    private MobilePageController mobilePageController;

    public DetalleComprasController() {
        // Inform the Abstract parent controller of the concrete DetalleCompras Entity
        super(DetalleCompras.class);
    }

    /**
     * Resets the "selected" attribute of any parent Entity controllers.
     */
    public void resetParents() {
        idAsientoController.setSelected(null);
        idCompraController.setSelected(null);
    }

    /**
     * Sets the "selected" attribute of the Asientos controller in order to
     * display its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareIdAsiento(ActionEvent event) {
        DetalleCompras selected = this.getSelected();
        if (selected != null && idAsientoController.getSelected() == null) {
            idAsientoController.setSelected(selected.getIdAsiento());
        }
    }

    /**
     * Sets the "selected" attribute of the Compras controller in order to
     * display its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareIdCompra(ActionEvent event) {
        DetalleCompras selected = this.getSelected();
        if (selected != null && idCompraController.getSelected() == null) {
            idCompraController.setSelected(selected.getIdCompra());
        }
    }

}

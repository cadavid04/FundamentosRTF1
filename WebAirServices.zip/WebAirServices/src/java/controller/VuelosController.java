package controller;

import Entity.Vuelos;
import Entity.Compras;
import java.util.Collection;
import facade.VuelosFacade;
import controller.util.MobilePageController;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

@Named(value = "vuelosController")
@ViewScoped
public class VuelosController extends AbstractController<Vuelos> {

    @Inject
    private MobilePageController mobilePageController;

    // Flags to indicate if child collections are empty
    private boolean isComprasCollectionEmpty;

    public VuelosController() {
        // Inform the Abstract parent controller of the concrete Vuelos Entity
        super(Vuelos.class);
    }

    /**
     * Set the "is[ChildCollection]Empty" property for OneToMany fields.
     */
    @Override
    protected void setChildrenEmptyFlags() {
        this.setIsComprasCollectionEmpty();
    }

    public boolean getIsComprasCollectionEmpty() {
        return this.isComprasCollectionEmpty;
    }

    private void setIsComprasCollectionEmpty() {
        Vuelos selected = this.getSelected();
        if (selected != null) {
            VuelosFacade ejbFacade = (VuelosFacade) this.getFacade();
            this.isComprasCollectionEmpty = ejbFacade.isComprasCollectionEmpty(selected);
        } else {
            this.isComprasCollectionEmpty = true;
        }
    }

    /**
     * Sets the "items" attribute with a collection of Compras entities that are
     * retrieved from Vuelos and returns the navigation outcome.
     *
     * @return navigation outcome for Compras page
     */
    public String navigateComprasCollection() {
        Vuelos selected = this.getSelected();
        if (selected != null) {
            VuelosFacade ejbFacade = (VuelosFacade) this.getFacade();
            Collection<Compras> selectedComprasCollection = ejbFacade.findComprasCollection(selected);
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("Compras_items", selectedComprasCollection);
        }
        return this.mobilePageController.getMobilePagesPrefix() + "/app/compras/index";
    }

}

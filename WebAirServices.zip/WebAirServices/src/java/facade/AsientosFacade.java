/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import Entity.Asientos;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import Entity.Asientos_;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Entity.DetalleCompras;
import java.util.Collection;

/**
 *
 * @author carloscarrascal
 */
@Stateless
public class AsientosFacade extends AbstractFacade<Asientos> {

    @PersistenceContext(unitName = "WebAirServicesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AsientosFacade() {
        super(Asientos.class);
    }

    public boolean isDetalleComprasCollectionEmpty(Asientos entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Asientos> asientos = cq.from(Asientos.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(asientos, entity), cb.isNotEmpty(asientos.get(Asientos_.detalleComprasCollection)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Collection<DetalleCompras> findDetalleComprasCollection(Asientos entity) {
        Asientos mergedEntity = this.getMergedEntity(entity);
        Collection<DetalleCompras> detalleComprasCollection = mergedEntity.getDetalleComprasCollection();
        detalleComprasCollection.size();
        return detalleComprasCollection;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import Entity.DetalleCompras;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import Entity.DetalleCompras_;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Entity.Asientos;
import Entity.Compras;

/**
 *
 * @author carloscarrascal
 */
@Stateless
public class DetalleComprasFacade extends AbstractFacade<DetalleCompras> {

    @PersistenceContext(unitName = "WebAirServicesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DetalleComprasFacade() {
        super(DetalleCompras.class);
    }

    public boolean isIdAsientoEmpty(DetalleCompras entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<DetalleCompras> detalleCompras = cq.from(DetalleCompras.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(detalleCompras, entity), cb.isNotNull(detalleCompras.get(DetalleCompras_.idAsiento)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Asientos findIdAsiento(DetalleCompras entity) {
        return this.getMergedEntity(entity).getIdAsiento();
    }

    public boolean isIdCompraEmpty(DetalleCompras entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<DetalleCompras> detalleCompras = cq.from(DetalleCompras.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(detalleCompras, entity), cb.isNotNull(detalleCompras.get(DetalleCompras_.idCompra)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Compras findIdCompra(DetalleCompras entity) {
        return this.getMergedEntity(entity).getIdCompra();
    }
    
}

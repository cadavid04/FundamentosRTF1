/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import Entity.Vuelos;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import Entity.Vuelos_;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Entity.Compras;
import java.util.Collection;

/**
 *
 * @author carloscarrascal
 */
@Stateless
public class VuelosFacade extends AbstractFacade<Vuelos> {

    @PersistenceContext(unitName = "WebAirServicesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public VuelosFacade() {
        super(Vuelos.class);
    }

    public boolean isComprasCollectionEmpty(Vuelos entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Vuelos> vuelos = cq.from(Vuelos.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(vuelos, entity), cb.isNotEmpty(vuelos.get(Vuelos_.comprasCollection)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Collection<Compras> findComprasCollection(Vuelos entity) {
        Vuelos mergedEntity = this.getMergedEntity(entity);
        Collection<Compras> comprasCollection = mergedEntity.getComprasCollection();
        comprasCollection.size();
        return comprasCollection;
    }
    
}

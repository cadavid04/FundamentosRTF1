/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import Entity.Compras;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import Entity.Compras_;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Entity.Socios;
import Entity.Vuelos;
import Entity.DetalleCompras;
import java.util.Collection;

/**
 *
 * @author carloscarrascal
 */
@Stateless
public class ComprasFacade extends AbstractFacade<Compras> {

    @PersistenceContext(unitName = "WebAirServicesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ComprasFacade() {
        super(Compras.class);
    }

    public boolean isIdSocioEmpty(Compras entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Compras> compras = cq.from(Compras.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(compras, entity), cb.isNotNull(compras.get(Compras_.idSocio)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Socios findIdSocio(Compras entity) {
        return this.getMergedEntity(entity).getIdSocio();
    }

    public boolean isIdVueloEmpty(Compras entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Compras> compras = cq.from(Compras.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(compras, entity), cb.isNotNull(compras.get(Compras_.idVuelo)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Vuelos findIdVuelo(Compras entity) {
        return this.getMergedEntity(entity).getIdVuelo();
    }

    public boolean isDetalleComprasCollectionEmpty(Compras entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Compras> compras = cq.from(Compras.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(compras, entity), cb.isNotEmpty(compras.get(Compras_.detalleComprasCollection)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Collection<DetalleCompras> findDetalleComprasCollection(Compras entity) {
        Compras mergedEntity = this.getMergedEntity(entity);
        Collection<DetalleCompras> detalleComprasCollection = mergedEntity.getDetalleComprasCollection();
        detalleComprasCollection.size();
        return detalleComprasCollection;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import Entity.Socios;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import Entity.Socios_;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Entity.Compras;
import java.util.Collection;

/**
 *
 * @author carloscarrascal
 */
@Stateless
public class SociosFacade extends AbstractFacade<Socios> {

    @PersistenceContext(unitName = "WebAirServicesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SociosFacade() {
        super(Socios.class);
    }

    public boolean isComprasCollectionEmpty(Socios entity) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Socios> socios = cq.from(Socios.class);
        cq.select(cb.literal(1L)).distinct(true).where(cb.equal(socios, entity), cb.isNotEmpty(socios.get(Socios_.comprasCollection)));
        return em.createQuery(cq).getResultList().isEmpty();
    }

    public Collection<Compras> findComprasCollection(Socios entity) {
        Socios mergedEntity = this.getMergedEntity(entity);
        Collection<Compras> comprasCollection = mergedEntity.getComprasCollection();
        comprasCollection.size();
        return comprasCollection;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author carloscarrascal
 */
@Entity
@Table(catalog = "aeroosdb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Asientos.findAll", query = "SELECT a FROM Asientos a")
    , @NamedQuery(name = "Asientos.findByIdAsiento", query = "SELECT a FROM Asientos a WHERE a.idAsiento = :idAsiento")
    , @NamedQuery(name = "Asientos.findByNumeroAsiento", query = "SELECT a FROM Asientos a WHERE a.numeroAsiento = :numeroAsiento")
    , @NamedQuery(name = "Asientos.findByEstado", query = "SELECT a FROM Asientos a WHERE a.estado = :estado")
    , @NamedQuery(name = "Asientos.findByClase", query = "SELECT a FROM Asientos a WHERE a.clase = :clase")
    , @NamedQuery(name = "Asientos.findByTarifa", query = "SELECT a FROM Asientos a WHERE a.tarifa = :tarifa")})
public class Asientos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_ASIENTO")
    private Integer idAsiento;
    @Basic(optional = false)
    @NotNull
    @Column(name = "NUMERO_ASIENTO")
    private int numeroAsiento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    private String clase;
    @Basic(optional = false)
    @NotNull
    private int tarifa;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idAsiento")
    private Collection<DetalleCompras> detalleComprasCollection;

    public Asientos() {
    }

    public Asientos(Integer idAsiento) {
        this.idAsiento = idAsiento;
    }

    public Asientos(Integer idAsiento, int numeroAsiento, String estado, String clase, int tarifa) {
        this.idAsiento = idAsiento;
        this.numeroAsiento = numeroAsiento;
        this.estado = estado;
        this.clase = clase;
        this.tarifa = tarifa;
    }

    public Integer getIdAsiento() {
        return idAsiento;
    }

    public void setIdAsiento(Integer idAsiento) {
        this.idAsiento = idAsiento;
    }

    public int getNumeroAsiento() {
        return numeroAsiento;
    }

    public void setNumeroAsiento(int numeroAsiento) {
        this.numeroAsiento = numeroAsiento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }

    public int getTarifa() {
        return tarifa;
    }

    public void setTarifa(int tarifa) {
        this.tarifa = tarifa;
    }

    @XmlTransient
    public Collection<DetalleCompras> getDetalleComprasCollection() {
        return detalleComprasCollection;
    }

    public void setDetalleComprasCollection(Collection<DetalleCompras> detalleComprasCollection) {
        this.detalleComprasCollection = detalleComprasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAsiento != null ? idAsiento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Asientos)) {
            return false;
        }
        Asientos other = (Asientos) object;
        if ((this.idAsiento == null && other.idAsiento != null) || (this.idAsiento != null && !this.idAsiento.equals(other.idAsiento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Asientos[ idAsiento=" + idAsiento + " ]";
    }
    
}
